A lot of ESC hex files are already integrated into the application. 
You may add new ESC here 
Add the ESC data into Besc.cfg as shown without the leading "//".
Hex and Eep files must be placed in the same folder. 
Besc.cfg data will override already existing internal ESC data. 
External hex/eep files with same revision will override internal.